<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'billing_pages_root');
define('DB_PASS', 'EUZc8x1r#wl%yp8z');
define('DB_NAME', 'billing_portal');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?> 