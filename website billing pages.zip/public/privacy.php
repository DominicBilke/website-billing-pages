<?php require_once __DIR__ . '/../inc/header.php'; ?>

<div class="content-container">
    <h1>Privacy Policy</h1>
    
    <div class="content-section">
        <h2>1. Data Protection at a Glance</h2>
        <h3>General Notes</h3>
        <p>The following notes provide a simple overview of what happens to your personal data when you visit this website. Personal data is any data that can personally identify you. Detailed information on the subject of data protection can be found in our privacy policy listed below this text.</p>

        <h3>Data Collection on This Website</h3>
        <h4>Who is responsible for data collection on this website?</h4>
        <p>Data processing on this website is carried out by the website operator. You can find the contact details of the website operator in the imprint of this website.</p>

        <h4>How do we collect your data?</h4>
        <p>Your data is collected when you provide it to us. This can be data that you enter in a contact form, for example.</p>
        <p>Other data is automatically collected by our IT systems when you visit the website. These are mainly technical data (e.g., internet browser, operating system, or time of page view). This data is collected automatically as soon as you enter this website.</p>

        <h4>What do we use your data for?</h4>
        <p>Part of the data is collected to ensure the proper functioning of the website. Other data can be used to analyze your user behavior.</p>

        <h4>What rights do you have regarding your data?</h4>
        <p>You have the right to receive information about the origin, recipient, and purpose of your stored personal data at any time. You also have the right to request the correction or deletion of this data. If you have given your consent to data processing, you can revoke this consent at any time for the future. You also have the right to request the restriction of the processing of your personal data under certain circumstances. Furthermore, you have the right to lodge a complaint with the competent supervisory authority.</p>
    </div>

    <div class="content-section">
        <h2>2. Hosting</h2>
        <p>We host our website with a professional hosting provider. The provider is responsible for the operation, maintenance, and security of the servers.</p>
    </div>

    <div class="content-section">
        <h2>3. General Notes and Mandatory Information</h2>
        <h3>Data Protection</h3>
        <p>The operators of these pages take the protection of your personal data very seriously. We treat your personal data confidentially and in accordance with the statutory data protection regulations and this privacy policy.</p>
        <p>When you use this website, various personal data is collected. Personal data is data that can personally identify you. This privacy policy explains what data we collect and what we use it for. It also explains how and for what purpose this happens.</p>
        <p>We would like to point out that data transmission on the Internet (e.g., when communicating by e-mail) can have security gaps. Complete protection of data against access by third parties is not possible.</p>
    </div>

    <div class="content-section">
        <h2>4. Data Collection on This Website</h2>
        <h3>Cookies</h3>
        <p>Our website uses cookies. These are small text files that your web browser stores on your device. Cookies help us make our offer more user-friendly, effective, and secure.</p>
        <p>Some cookies are "session cookies." Such cookies are automatically deleted after the end of your browser session. On the other hand, other cookies remain on your device until you delete them yourself. Such cookies help us to recognize you when you return to our website.</p>
    </div>

    <div class="content-section">
        <h2>5. Contact</h2>
        <p>For questions about data protection, please contact us at:</p>
        <p>Dominic Bilke<br>
        Email: contact@dominic-bilke.de</p>
    </div>
</div>

<?php require_once __DIR__ . '/../inc/footer.php'; ?> 