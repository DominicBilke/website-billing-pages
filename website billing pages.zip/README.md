# Billing Portal

A professional billing portal built with HTML, CSS, JavaScript, PHP, and MySQL.

## Features

- User authentication (register/login/logout)
- Dashboard with invoice summary
- Client management
- Invoice management
- Privacy Policy and Imprint pages

## Requirements

- PHP 7.4+
- MySQL/MariaDB
- Apache/Nginx

## Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd billing-portal
   ```

2. Create a MySQL database and import the schema:
   ```bash
   mysql -u root -p < sql/schema.sql
   ```

3. Configure the database connection in `config/db.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'your_username');
   define('DB_PASS', 'your_password');
   define('DB_NAME', 'billing_portal');
   ```

4. Set up your web server (Apache/Nginx) to point to the `public` directory.

5. Access the portal at `http://your-server-ip/`.

## Deployment on Ubuntu

1. Install Apache, PHP, and MySQL:
   ```bash
   sudo apt update
   sudo apt install apache2 php mysql-server
   ```

2. Enable PHP and MySQL modules:
   ```bash
   sudo a2enmod php
   sudo systemctl restart apache2
   ```

3. Configure Apache to point to the `public` directory:
   ```bash
   sudo nano /etc/apache2/sites-available/000-default.conf
   ```
   Update the `DocumentRoot` to point to the `public` directory.

4. Restart Apache:
   ```bash
   sudo systemctl restart apache2
   ```

## Creator

Created by [Bilke Web Software](http://www.bilke-web-sw.de/en/). 