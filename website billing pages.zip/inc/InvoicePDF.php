<?php
require_once __DIR__ . '/../vendor/tecnickcom/tcpdf/tcpdf.php';

class InvoicePDF extends TCPDF {
    private $invoice;
    private $client;

    public function __construct($invoice, $client) {
        parent::__construct(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        $this->invoice = $invoice;
        $this->client = $client;

        // Set document information
        $this->SetCreator('Billing Portal');
        $this->SetAuthor('Billing Portal');
        $this->SetTitle('Invoice #' . $invoice['id']);

        // Set default header data
        $this->SetHeaderData('', 0, 'INVOICE', 'Invoice #' . $invoice['id']);

        // Set margins
        $this->SetMargins(15, 15, 15);
        $this->SetHeaderMargin(5);
        $this->SetFooterMargin(10);

        // Set auto page breaks
        $this->SetAutoPageBreak(TRUE, 15);

        // Set default monospaced font
        $this->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

        // Set font
        $this->SetFont('helvetica', '', 10);
    }

    public function generate() {
        // Add a page
        $this->AddPage();

        // Company Information
        $this->SetFont('helvetica', 'B', 12);
        $this->Cell(0, 10, 'Billing Portal', 0, 1, 'R');
        $this->SetFont('helvetica', '', 10);
        $this->Cell(0, 5, '123 Business Street', 0, 1, 'R');
        $this->Cell(0, 5, 'City, State 12345', 0, 1, 'R');
        $this->Cell(0, 5, 'contact@billingportal.com', 0, 1, 'R');
        $this->Ln(10);

        // Client Information
        $this->SetFont('helvetica', 'B', 12);
        $this->Cell(0, 10, 'Bill To:', 0, 1);
        $this->SetFont('helvetica', '', 10);
        $this->Cell(0, 5, $this->client['name'], 0, 1);
        $this->MultiCell(0, 5, $this->client['address'], 0, 'L');
        $this->Cell(0, 5, $this->client['email'], 0, 1);
        $this->Cell(0, 5, $this->client['phone'], 0, 1);
        $this->Ln(10);

        // Invoice Details
        $this->SetFont('helvetica', 'B', 12);
        $this->Cell(0, 10, 'Invoice Details', 0, 1);
        $this->SetFont('helvetica', '', 10);
        $this->Cell(40, 5, 'Invoice Date:', 0, 0);
        $this->Cell(0, 5, date('F j, Y', strtotime($this->invoice['date'])), 0, 1);
        $this->Cell(40, 5, 'Due Date:', 0, 0);
        $this->Cell(0, 5, date('F j, Y', strtotime($this->invoice['due_date'])), 0, 1);
        $this->Cell(40, 5, 'Status:', 0, 0);
        $this->Cell(0, 5, ucfirst($this->invoice['status']), 0, 1);
        $this->Ln(10);

        // Invoice Items Table Header
        $this->SetFont('helvetica', 'B', 10);
        $this->Cell(120, 7, 'Description', 1, 0, 'C');
        $this->Cell(30, 7, 'Amount', 1, 1, 'C');

        // Invoice Total
        $this->SetFont('helvetica', 'B', 10);
        $this->Cell(120, 7, 'Total', 1, 0, 'R');
        $this->Cell(30, 7, '€' . number_format($this->invoice['total'], 2), 1, 1, 'C');

        // Footer
        $this->Ln(20);
        $this->SetFont('helvetica', 'I', 8);
        $this->Cell(0, 5, 'Thank you for your business!', 0, 1, 'C');
        $this->Cell(0, 5, 'This is a computer-generated invoice, no signature required.', 0, 1, 'C');
    }
} 