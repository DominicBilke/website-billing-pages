    </main>
    <footer>
        <p>&copy; 2023 Billing Portal. All rights reserved.</p>
    </footer>
</body>
</html> 