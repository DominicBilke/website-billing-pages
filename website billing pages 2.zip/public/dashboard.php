<?php
require_once __DIR__ . '/../inc/header.php';
require_once __DIR__ . '/../config/db.php';

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT COUNT(*) as total_invoices FROM invoices WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$total_invoices = $row['total_invoices'];
?>
<h1>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h1>
<p>You have <?php echo $total_invoices; ?> invoices.</p>
<a href="invoices.php">View Invoices</a>
<?php require_once __DIR__ . '/../inc/footer.php'; ?> 