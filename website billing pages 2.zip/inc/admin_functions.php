<?php
require_once 'db.php';

function isAdmin($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    return $user && $user['is_admin'] == 1;
}

function getPaymentSettings() {
    global $pdo;
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM payment_settings");
    $settings = [];
    while ($row = $stmt->fetch()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    return $settings;
}

function updatePaymentSetting($key, $value) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE payment_settings SET setting_value = ? WHERE setting_key = ?");
    return $stmt->execute([$value, $key]);
}

function getPaymentMethods() {
    $settings = getPaymentSettings();
    return explode(',', $settings['payment_methods']);
}

function getCompanyBankDetails() {
    $settings = getPaymentSettings();
    return json_decode($settings['company_bank_details'], true);
}

function getPaymentStats() {
    global $pdo;
    $stats = [];
    
    // Total payments
    $stmt = $pdo->query("SELECT COUNT(*) FROM payments");
    $stats['total_payments'] = $stmt->fetchColumn();
    
    // Total amount
    $stmt = $pdo->query("SELECT SUM(amount) FROM payments WHERE status = 'completed'");
    $stats['total_amount'] = $stmt->fetchColumn() ?: 0;
    
    // Pending payments
    $stmt = $pdo->query("SELECT COUNT(*) FROM payments WHERE status = 'pending'");
    $stats['pending_payments'] = $stmt->fetchColumn();
    
    // Failed payments
    $stmt = $pdo->query("SELECT COUNT(*) FROM payments WHERE status = 'failed'");
    $stats['failed_payments'] = $stmt->fetchColumn();
    
    return $stats;
} 